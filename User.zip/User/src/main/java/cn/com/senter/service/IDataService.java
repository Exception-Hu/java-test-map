package cn.com.senter.service;

import java.util.Date;
import java.util.List;

import javax.xml.crypto.Data;

import org.springframework.web.bind.annotation.RequestParam;

import cn.com.senter.entity.Details;
import cn.com.senter.entity.DetailsMessage;
import cn.com.senter.entity.Message;
import cn.com.senter.service.ex.DetailsNotFound;
import cn.com.senter.service.ex.MessageCreateTimeNotFound;
import cn.com.senter.service.ex.MessageNotFound;

/**
 * 隐患了类型业务层
 * @author Administrator
 *
 */
public interface IDataService {
	
	/**
	 * 根据查询条件，查询隐患详情
	 * @return 封转隐患详情的List集合
	 * @throws MessageNotFound 没有隐患
	 * @throws MessageCreateTimeNotFound 输入的时间没有找到数据
	 */
	List<Message> selectTrouble(Message message, Date startTime, Date overTime)throws MessageNotFound,MessageCreateTimeNotFound;
	/**
	 * 根据坐标x,y查询隐患详情
	 * @param x x坐标
	 * @param y y坐标
	 * @return 
	 * @throws DetailsNotFound 没有详情数据
	 */
	DetailsMessage selectCoordinates(String x,String y)throws DetailsNotFound,MessageNotFound;
}
