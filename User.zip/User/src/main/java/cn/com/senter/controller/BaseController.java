package cn.com.senter.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.com.senter.service.ex.DetailsNotFound;
import cn.com.senter.service.ex.InsertException;
import cn.com.senter.service.ex.MessageCreateTimeNotFound;
import cn.com.senter.service.ex.MessageNotFound;
import cn.com.senter.service.ex.PasswordNotFoundException;
import cn.com.senter.service.ex.PhoneNotFoundException;
import cn.com.senter.service.ex.ServlerException;
import cn.com.senter.service.ex.UploadException;
import cn.com.senter.service.ex.UserNotFoundException;
import cn.com.senter.util.JsonReult;

/**
 * 信息处理类
 * @author Administrator
 *
 */
public class BaseController {
	
	/**
	 * 异常信息处理
	 * @param e 
	 * @return
	 */
	@ExceptionHandler(ServlerException.class)
	@ResponseBody
	public JsonReult ExceptionHandler(Throwable e) {
		JsonReult json = new JsonReult();
		if(e instanceof UserNotFoundException) {
			json.setState(101);
		}else if(e instanceof UploadException) {
			json.setState(102);
		}else if(e instanceof PasswordNotFoundException) {
			json.setState(103);
		}else if (e instanceof PhoneNotFoundException) {
			json.setState(104); 
		}else if(e instanceof InsertException) {
			json.setState(501);
		}else if (e instanceof MessageNotFound) {
			json.setState(105);
		}else if (e instanceof DetailsNotFound) {
			json.setState(106);
		}else if(e instanceof MessageCreateTimeNotFound) {
			json.setState(107);
		}
		json.setMessage(e.getMessage());
		return json;
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh-mm-ss");
		sdf.setLenient(false);
		binder.registerCustomEditor(Date.class,new CustomDateEditor(sdf, true));
	}
}
