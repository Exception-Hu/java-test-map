package cn.com.senter.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import cn.com.senter.entity.User;
import cn.com.senter.service.IUserService;
import cn.com.senter.service.ex.PasswordNotFoundException;
import cn.com.senter.service.ex.UserNotFoundException;
import cn.com.senter.util.JsonReult;
/**
 * 用户控制器层
 * @author Administrator
 *
 */
@RestController
@RequestMapping("user")
public class UserController extends BaseController{
	
	 public final static Logger LOGGER = LoggerFactory.getLogger(UserController.class);
	
	@Autowired 
	private IUserService service;
	
	/**
	 * 用户注册
	 * @param user 用户实体类
	 * @return
	 */
	@PostMapping("reg")
	public JsonReult<Void> reg(@RequestParam("file") MultipartFile file ,User user,HttpServletRequest request) {
		LOGGER.warn("数据进入控制器层：开始注册:"+user.getUsername());
		service.reg(file, user, request);
		LOGGER.warn("数据返回控制器层：注册结束:"+user.getUsername());
		return new JsonReult<Void>(100,"注册成功");
		
	}
	
	/**
	 * 用户登入
	 * @param user 用户实体类
	 * @return
	 */
	@SuppressWarnings("null")
	@RequestMapping("login")
	public JsonReult<User> login(User user,HttpSession session) {
		LOGGER.warn("数据进入控制器层：开始登入:"+user.getUsername());
		if(session.getAttribute("username")!=null) {
			String username = session.getAttribute("username").toString();
			if(username.equals(user.getUsername())) {
				return new JsonReult<User>(103,"用户以登入");
			}
		}
		
		//用户数据类 
		User result = null;
		try {
			result = service.login(user);
		} catch (UserNotFoundException e) {
			throw new UserNotFoundException("用户名不存在");
		}catch (PasswordNotFoundException e) {
			throw new PasswordNotFoundException("用户密码错误");
		}catch (Exception e) {
			LOGGER.error(e.getClass().toString());
			LOGGER.error(e.getMessage());
		}
		//下发session对象
		session.setAttribute("id", result.getId());
		session.setAttribute("username", result.getUsername());
		LOGGER.warn("数据返回控制器层：登入结束:"+user.getUsername());
		//返回对象
		return new JsonReult<User>(100,result);
	}
	
	/**
	 * 根据用户名查询用户照片
	 * @param session
	 * @return
	 */
	@RequestMapping("phone")
	public JsonReult<User> phone(HttpSession session){
		
		LOGGER.warn("数据进入控制器层：查找照片:");
		User user = null;
		String username = session.getAttribute("username").toString();
		user= service.phone(username);
		LOGGER.warn("数据返回控制器层：查找照片结束:"+username);
		return new JsonReult<User>(100,user);
	}
	
	/**
	 * 查询所有用户数据
	 */
	@RequestMapping("selData")
	public JsonReult<List<User>> selData(){
		LOGGER.warn("数据进入控制器层：查找所有用户数据");
		List<User> user = service.selData();
		LOGGER.warn("数据返回控制器层：查找所有用户数据结束");
		return new JsonReult<List<User>>(100,user);
	}
	
}
