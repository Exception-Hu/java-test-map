package cn.com.senter.entity;

/**
 * 隐患详情
 * @author Administrator
 *
 */
public class Details {
	private int id;
	private int mId;
	private String writeTime;
	private String foundTime;
	private String serialNumber;
	private String writeName;
	private String phone;
	private String describe;
	private String plan;
	private String photo;
	private String video;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getmId() {
		return mId;
	}
	public void setmId(int mId) {
		this.mId = mId;
	}
	public String getWriteTime() {
		return writeTime;
	}
	public void setWriteTime(String writeTime) {
		this.writeTime = writeTime;
	}
	public String getFoundTime() {
		return foundTime;
	}
	public void setFoundTime(String foundTime) {
		this.foundTime = foundTime;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getWriteName() {
		return writeName;
	}
	public void setWriteName(String writeName) {
		this.writeName = writeName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getDescribe() {
		return describe;
	}
	public void setDescribe(String describe) {
		this.describe = describe;
	}
	public String getPlan() {
		return plan;
	}
	public void setPlan(String plan) {
		this.plan = plan;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public String getVideo() {
		return video;
	}
	public void setVideo(String video) {
		this.video = video;
	}
	@Override
	public String toString() {
		return "details [id=" + id + ", mId=" + mId + ", writeTime=" + writeTime + ", foundTime=" + foundTime
				+ ", serialNumber=" + serialNumber + ", writeName=" + writeName + ", phone=" + phone + ", describe="
				+ describe + ", plan=" + plan + ", photo=" + photo + ", video=" + video + "]";
	}
}
