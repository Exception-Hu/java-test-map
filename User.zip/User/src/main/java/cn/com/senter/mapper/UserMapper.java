package cn.com.senter.mapper;

import java.util.List;

import cn.com.senter.entity.User;

/**
 * 用户持久层
 * @author Administrator
 *
 */
public interface UserMapper {
	
	/**
	 * 根据用户名查询用户数据
	 * @param id
	 * @return
	 */
	User findByName(String username);
	
	/**
	 * 添加用户数据
	 * @param user
	 * @return
	 */
	Integer insertByUser(User user);
	
	/**
	 * 查询用户数据
	 * @return
	 */
	List<User> allUser();
	
	
}
