package cn.com.senter.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
/**
 * 页面返回控制器层
 * @author Administrator
 *
 */
@Controller 
public class PageController {
	
	/**
	 * @return 返回用户注册页面
	 */
	@RequestMapping("reg")
	public String reg() {
		System.err.println("PageController.reg()");
		return "reg";
	}
	
	/**
	 * 
	 * @return 返回用户登入页面
	 */
	@RequestMapping("login")
	public String login() {
		System.err.println("PageController.login()");
		return "login";
	}
	
	
	@RequestMapping("image")
	public String image() {
		System.err.println("PageController.image()");
		return "image";
	}
}
