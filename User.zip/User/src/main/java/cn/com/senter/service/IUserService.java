package cn.com.senter.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import cn.com.senter.entity.User;
import cn.com.senter.entity.UserState;
import cn.com.senter.service.ex.InsertException;
import cn.com.senter.service.ex.PasswordNotFoundException;
import cn.com.senter.service.ex.PhoneNotFoundException;
import cn.com.senter.service.ex.UploadException;
import cn.com.senter.service.ex.UserNotFoundException;

/**
 * 业务层接口
 * @author Administrator
 *
 */
public interface IUserService {
	
	/**
	 * 用户注册 
	 * @param file 用户上传文件 
	 * @param user 封装了用户数据的实体类
	 * @param request 用来获取项目地址
	 * @throws UserNotFoundException 用户名已存在
	 * @throws UploadException 上传不能为空、文件超出范围、文件类型不匹配
	 * @throws InsertException 添加异常
	 */
	void reg(MultipartFile file, User user,HttpServletRequest request) throws UserNotFoundException,UploadException,InsertException;
	
	/**
	 * 用户登入
	 * @param user 封装了用户数据的实体类
	 * @return 封装了用户数据的实体类
	 * @throws UserNotFoundException 用户名不存在异常
	 * @throws PasswordNotFoundException 用户密码不正确异常
	 */
	User login(User user) throws UserNotFoundException,PasswordNotFoundException;
	
	/**
	 * 获取照片路径
	 * @param username 用户名
	 * @return 封装了用户数据
	 * @throws UserNotFoundException 用户名没有找到异常
	 * @throws PhoneNotFoundException 没有用户照片
	 */
	User phone(String username)throws UserNotFoundException,PhoneNotFoundException;
	
	/**
	 * 查询所有用户数据
	 * @return 
	 */
	List<User> selData()throws UserNotFoundException;
}
