package cn.com.senter.service.ex;

/**
 * 没有用户照片异常
 * @author Administrator
 *
 */
public class PhoneNotFoundException extends ServlerException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5112244572420236036L;

	public PhoneNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PhoneNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public PhoneNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PhoneNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PhoneNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
