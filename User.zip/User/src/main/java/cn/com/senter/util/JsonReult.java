package cn.com.senter.util;

import java.lang.Thread.State;

/**
 * 信息返回类
 * @author Administrator
 *
 */
public class JsonReult<E> {
	private Integer state;
	
	private String message;
	
	private E data;
	
	public E getData() {
		return data;
	}

	public void setData(E data) {
		this.data = data;
	}

	public JsonReult() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public JsonReult(Integer state) {
		super();
		this.state = state;
	}
	
	public JsonReult(Integer state, String message) {
		super();
		this.state = state;
		this.message = message;
	}
	

	public JsonReult(Integer state, E data) {
		super();
		this.state = state;
		this.data = data;
	}

	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
