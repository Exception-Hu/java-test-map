package cn.com.senter.service.impl;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.javassist.expr.NewArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import cn.com.senter.entity.User;
import cn.com.senter.mapper.UserMapper;
import cn.com.senter.service.IUserService;
import cn.com.senter.service.ex.InsertException;
import cn.com.senter.service.ex.PasswordNotFoundException;
import cn.com.senter.service.ex.PhoneNotFoundException;
import cn.com.senter.service.ex.UploadException;
import cn.com.senter.service.ex.UserNotFoundException;

/**
 * 用户业务层
 * @author Administrator
 *
 */
@Service
public class UserService implements IUserService{
	
	final static Logger LOGGER = LoggerFactory.getLogger(UserService.class);
	private static SimpleDateFormat sdf = null;
	{
		 sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	}
	
	@Autowired
	private UserMapper mapper;

	/**
	 * 用户注册
	 */
	@Override
	public void reg(MultipartFile file,User user,HttpServletRequest request) throws UserNotFoundException,UploadException,InsertException{
		LOGGER.warn("数据进入用户注册业务层:"+user.getUsername());
		//获取用户名
		String username = user.getUsername();
		//根据用户名查询用户数据
		User result = mapper.findByName(username);
		//如果数据不为null，则表示有用户数据
		//不为null，则注册
		if(result!=null) {
			LOGGER.error("注册异常-->用户名已存在："+user.getUsername());
			throw new UserNotFoundException("用户名已存在");
		}
		String phone = phone(file, request);
		
		
		//添加用户类型
		user.setRole(1);
		//添加照片路径
		user.setPhone(phone);
		//添加创建信息
		user.setCreateTime(sdf.format(new Date()));
		//添加用户数据
		Integer row = mapper.insertByUser(user);
		//如果受影响的行数不为1，则添加错误
		if(row!=1) {
			LOGGER.error("注册异常-->请联系管理员："+user.getUsername());
			throw new InsertException("用户注册异常，请联系管理员");
		}
		LOGGER.warn("数据返回用户注册业务层:"+user.getUsername());
		
	}
	 
	/**
	 * 用户登入
	 */
	@Override
	public User login(User user) throws UserNotFoundException,PasswordNotFoundException{
		LOGGER.warn("数据进入用户登入业务层:"+user.getUsername());
		//获取用户输入的用户名
		String username = user.getUsername();
		//获取用户输入的密码、
		String password = user.getPassword();
 		//根据用户名查询用户数据
		User result = mapper.findByName(username);
		//如果没有用户数据
		if(result==null) {
			LOGGER.error("登入异常-->用户名错误："+user.getUsername());
			throw new UserNotFoundException("用户名错误");
		} 
		//获取数据库密码
		String pwd = result.getPassword();
		//用户密码与输入密码比对,如果密码不匹配
		if(!pwd.equals(password)) {
			LOGGER.error("登入异常-->密码错误："+user.getUsername());
			throw new PasswordNotFoundException("密码错误");
		}
		//把密码设置为null
		result.setPassword(null);
		LOGGER.warn("数据返回用户登入业务层:"+user.getUsername());
		return result;
	}
	
	/**
	 * 获取照片路径
	 */
	@Override
	public User phone(String username) throws UserNotFoundException,PhoneNotFoundException {
		LOGGER.warn("数据进入获取照片业务层:"+username);
		User result = mapper.findByName(username);
		if(result==null) {
			LOGGER.error("获取照片异常-->用户名不存在："+username);
			throw new UserNotFoundException("用户不存在");
		}
		if(result.getPhone()==null||result.getPhone()==""||result.getPhone().length()==0) {
			LOGGER.error("获取照片异常-->没有用户照片:"+username);
			throw new PhoneNotFoundException("没有用户照片");
		}
		result.setPassword(null);
		LOGGER.warn("数据返回获取照片业务层:"+username);
		return result;
	}
	
	/**
	 * 查询所有用户所有数据
	 */
	@Override
	public List<User> selData() throws UserNotFoundException {
		List<User> result = mapper.allUser();
		if(result==null) {
			throw new UserNotFoundException("没有数据");
		}
		for (User user : result) {
			user.setPassword(null);
		}
		return result;
	}
	
	/**
	 * 添加照片
	 * @param file 文件
	 * @param request 获取项目路径
	 * @return 文件名
	 */
	private String phone(MultipartFile file,HttpServletRequest request) {
		LOGGER.warn("用户上传照片开始");
		if(file.isEmpty()) {
			LOGGER.error("上传照片不能为空");
			throw new UploadException("上传文件不能为空");
		}
		long fileSize = file.getSize();
		if(fileSize>1024*1024*0.5) {
			LOGGER.error("上传照片超出范围");
			throw new UploadException("上传文件超出范围");
		}
		List<String> list = new ArrayList<String>();
		list.add("image/jpeg");
		list.add("image/png");
		if(!list.contains(file.getContentType())) {
			LOGGER.error("上传照片类型不匹配");
			throw new UploadException("上传文件类型不匹配");
		}
		String fileName = file.getOriginalFilename();
		Integer index = fileName.lastIndexOf(".");
		if(index>0) {
			fileName = fileName.substring(index);
		}
		String newFileName = UUID.randomUUID().toString()+fileName;
		String filePath = request.getServletContext().getRealPath("upload");
		File parrnt = new File(filePath);
		if(!parrnt.exists()) {
			parrnt.mkdir();
		}
		File dest = new File(parrnt,newFileName);
		try {
			file.transferTo(dest);
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOGGER.warn("用户上传照片开始");
		return "/upload/"+newFileName;
	}

	

	
	
}
