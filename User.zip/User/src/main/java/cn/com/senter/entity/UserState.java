package cn.com.senter.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 业务层返回控制器层用户数据类
 * @author Administrator
 *
 */
public class UserState implements Serializable{ 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String username;
	private String phone;
	private Date createTime;
	private Integer state;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "UserState [id=" + id + ", username=" + username + ", phone=" + phone + ", createTime=" + createTime
				+ ", state=" + state + "]";
	}
	
	
}
