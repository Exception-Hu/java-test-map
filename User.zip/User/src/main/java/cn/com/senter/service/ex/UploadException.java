package cn.com.senter.service.ex;

/**
 * 上传照片不能为空异常
 * 上传照片数据超出范围异常
 * 上传照片格式不正确异常
 * @author Administrator
 *
 */
public class UploadException extends ServlerException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5112244572420236036L;

	public UploadException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UploadException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public UploadException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UploadException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UploadException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
