package cn.com.senter.mapper;
/**
 * 隐患详情持久层
 * @author Administrator
 *
 */

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.com.senter.entity.Details;
import cn.com.senter.entity.DetailsMessage;
import cn.com.senter.entity.Message;
import cn.com.senter.entity.MessageListTime;

public interface DataMapper {
	/**
	 * 根据资源信息查询隐患
	 * @param message
	 * @return
	 */
	List<Message> selMessage(@Param("message") Message message,
							 @Param("createDates") List<String> createDates);
	
	/**
	 * 根据坐标x,y查询数据
	 * @param x x坐标
	 * @param y y坐标
	 * @return 
	 */
	Integer selByXY(@Param("x")String x,@Param("y")String y);
	
	/**
	 * 根据用户id查询隐患详情
	 * @param id 用户id
	 * @return
	 */
	DetailsMessage selById(Integer id);
}
