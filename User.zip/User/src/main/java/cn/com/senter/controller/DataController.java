package cn.com.senter.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import cn.com.senter.entity.Details;
import cn.com.senter.entity.DetailsMessage;
import cn.com.senter.entity.Message;
import cn.com.senter.service.IDataService;
import cn.com.senter.service.ex.MessageNotFound;
import cn.com.senter.util.JsonReult;

/**
 * 隐患详情控制器层
 * @author Administrator
 *
 */
@RestController
@RequestMapping("message")
public class DataController extends BaseController{
	@Autowired
	private IDataService service;
	
	/**
	 * 根据查询条件与开始结束时间查询结果
	 * @param message 查询条件 实体类
	 * @param startTime 开始时间
	 * @param overTime 结束时间
	 * @return List<Message>集合
	 */
	@RequestMapping("trouble")
	@ResponseBody
	public JsonReult<List<Message>> selectTrouble(Message message,String startTime,String overTime){
		//时间转化
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		//查询结果
		List<Message> messages = null;
		try {
			//开始时间与结束时间为null
			Date sTime = null;
			Date oTime = null;
			//如果开始时间为空串或者为null,则开始时间为null，否则类型转换
			if(startTime=="" || startTime==null) {
				sTime = null;
			}else {
				sTime = sdf.parse(startTime);
			}
			//如果结束时间为空串或者为null,则结束时间为null，否则类型转换
			if(overTime=="" || overTime==null) {
				overTime=null;
			}else {
				oTime = sdf.parse(overTime);
			}
			//调用业务层方法
			messages = service.selectTrouble(message,sTime,oTime);
		}catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//返回状态码和查询结果
		return new JsonReult<List<Message>>(100,messages);
	}
	
	/**
	 * 根据坐标查询结果
	 * @param x x坐标
	 * @param y y坐标
	 * @return DetailsMessage实体类
	 */
	@RequestMapping("{xC}/{yC}/details")
	public JsonReult<DetailsMessage> selectCoordinates(@PathVariable("xC")String x,@PathVariable("yC")String y){
		//调用业务层方法
		DetailsMessage detailsMessage = service.selectCoordinates(x, y);
		//返回结果
		return new JsonReult<DetailsMessage>(100,detailsMessage);
	}
}
