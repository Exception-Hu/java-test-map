package cn.com.senter.service.impl;



import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.spi.DirStateFactory.Result;
import javax.swing.text.DefaultStyledDocument;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.senter.entity.Details;
import cn.com.senter.entity.DetailsMessage;
import cn.com.senter.entity.Message;
import cn.com.senter.mapper.DataMapper;
import cn.com.senter.service.IDataService;
import cn.com.senter.service.ex.DetailsNotFound;
import cn.com.senter.service.ex.MessageCreateTimeNotFound;
import cn.com.senter.service.ex.MessageNotFound;

/**
 * 隐患详情实现类
 * @author Administrator
 *
 */
@Service
public class DataService implements IDataService{
	
	@Autowired
	private DataMapper mapper;
	
	/**
	 * 查询隐患
	 */
	@Override
	public List<Message> selectTrouble(Message message, Date startTime, Date overTime) throws MessageNotFound,MessageCreateTimeNotFound {
		//默认开始结束时间戳为0
		long sTime = 0;
		long oTime = 0;
		//如果开始结束时间不为null，转换为时间戳
		if(startTime!=null) {
			sTime = startTime.getTime();
		}
		if(overTime!=null) {
			oTime = overTime.getTime();
		}
		//如果结束时间大于开始时间并且开始时间和结束时间不为null
		if((sTime>oTime)&&(startTime!=null)&&(overTime!=null)) {
			throw new MessageCreateTimeNotFound("开始时间不能大于结束时间");
		}
		//根据查询条件查询隐患
		List<Message> requestList = mapper.selMessage(message, null);
		//如果查询结果为null，或者长度为0,则返回没有隐患
		if(requestList==null||requestList.size()==0) {
			throw new MessageCreateTimeNotFound("没有查询到隐患详情");
		}
		
		//如果开始结束时间都不为null,则根据查询条件和开始 结束时间戳查询
		if(startTime!=null || overTime!=null) {
			requestList = ByTime(message, requestList, sTime, oTime);
		}
		//如果查询结果为null，或者长度为0,则返回没有隐患
		if(requestList==null||requestList.size()==0) {
			throw new MessageCreateTimeNotFound("没有查询到隐患详情");
		}
		//返回结果
		return requestList;
	}

	/**
	 * 查询隐患详情
	 */
	@Override
	public DetailsMessage selectCoordinates(String x, String y) throws DetailsNotFound,MessageNotFound{
		//根据坐标查询id
		Integer id = mapper.selByXY(x, y);
		//如果为null，返回-没有查询到信息
		if(id==null) {
			throw new MessageNotFound("没有查询到信息");
		}
		//根据id查询隐患详情
		DetailsMessage detailsMessage = mapper.selById(id);
		//如果查询隐患详情为null 返回-没有查询到隐患详情
		if(detailsMessage==null) {
			throw new DetailsNotFound("没有查询到隐患详情");
		}
		//返回结果
		return detailsMessage;
	}
	
	/**
	 * 根据传入的开始时间戳与结束时间戳，查找数据库的创建时间
	 * @param message 控制次传入的搜索数据
	 * @param requestList 数据库查询结果
	 * @param sTime 开始时间戳  
	 * @param oTime 结束时间戳
	 * @return
	 */
	
	
	private List<Message> ByTime(Message message,List<Message> requestList,long sTime,long oTime)throws MessageCreateTimeNotFound{
		//查询时间集合
		List<String> time = new ArrayList<String>();
		//时间转换
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		for (Message list : requestList) {
			Date date = null;
			try {
				//把数据库查询的时间转换为Date类型
				date = sdf.parse(list.getCreateTime());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			//把查询的Date类型的时间，转换为时间戳
			long cTime = date.getTime();
			//如果查询时间戳大于等于开始时间戳 并且 查询时间戳小于等于结束时间戳
			if(cTime>=sTime&&cTime<=oTime) {
				//添加到时间集合中
				time.add(list.getCreateTime());
				//如果查询时间戳大于等于开始时间戳 并且 结束时间戳为0
			}else if(cTime>=sTime&&oTime==0) {
				//添加到时间集合中
				time.add(list.getCreateTime());
			}else if(oTime<=sTime&&sTime==0) {
				//添加到时间集合中
				time.add(list.getCreateTime());
			}
		}
		//如果时间集合为null或者长度为0则结束查询
		if(time==null||time.size()==0) {
			throw new MessageCreateTimeNotFound("该时间段没有隐患信息");
		}
		//返回结果
		return mapper.selMessage(message,time);
		
	}
}
