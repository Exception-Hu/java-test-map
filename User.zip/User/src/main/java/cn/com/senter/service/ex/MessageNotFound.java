package cn.com.senter.service.ex;

/**
 * 隐患详情异常
 * @author Administrator
 *
 */
public class MessageNotFound extends ServlerException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5112244572420236036L;

	public MessageNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MessageNotFound(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public MessageNotFound(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MessageNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MessageNotFound(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
