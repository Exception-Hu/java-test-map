package cn.com.senter.config;

import java.util.ArrayList;

import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import cn.com.senter.interceptor.LoginInterceptor;
@Configuration
public class InterceptorConfigurer implements WebMvcConfigurer{

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		HandlerInterceptor hadler = new LoginInterceptor();
		InterceptorRegistration interceptor = registry.addInterceptor(hadler);
		interceptor.addPathPatterns("/**");
		List<String> patterns = new ArrayList<String>();
//		patterns.add("/login");
//		patterns.add("/reg");
		
		patterns.add("/web/reg.html");
		patterns.add("/web/login.html");
		patterns.add("/user/reg");
		patterns.add("/user/login");
		
		patterns.add("/web/js/jquery-3.4.1.min.js");
		patterns.add("/web/js/login.js");
		patterns.add("/web/js/reg.js");
		
		interceptor.excludePathPatterns(patterns);
	}
	
}
