package cn.com.senter.entity;

import java.util.Date;

/**
 * 资源信息表
 * @author Administrator
 *
 */
public class Message {
	private int id ; // '资源id'
	private String unit;// '单位',
	private String createTime;// '创建时间',
	private String vGrade ;// '电压等级',
	private String hazardType;// '隐患类型',
	private String hazardLevel ;// '隐患等级',
	private String x ;//'x坐标',
	private String y ;// 'y坐标'
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getvGrade() {
		return vGrade;
	}
	public void setvGrade(String vGrade) {
		this.vGrade = vGrade;
	}
	public String getHazardType() {
		return hazardType;
	}
	public void setHazardType(String hazardType) {
		this.hazardType = hazardType;
	}
	public String getHazardLevel() {
		return hazardLevel;
	}
	public void setHazardLevel(String hazardLevel) {
		this.hazardLevel = hazardLevel;
	}
	public String getX() {
		return x;
	}
	public void setX(String x) {
		this.x = x;
	}
	public String getY() {
		return y;
	}
	public void setY(String y) {
		this.y = y;
	}
	@Override
	public String toString() {
		return "Message [id=" + id + ", unit=" + unit + ", createTime=" + createTime + ", vGrade=" + vGrade
				+ ", hazardType=" + hazardType + ", hazardLevel=" + hazardLevel + ", x=" + x + ", y=" + y + "]";
	}
	
	
	
	
}
