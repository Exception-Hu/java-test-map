-- --------------------------------------------------------
-- 主机:                           127.0.0.1
-- 服务器版本:                        5.5.47-MariaDB - mariadb.org binary distribution
-- 服务器操作系统:                      Win64
-- HeidiSQL 版本:                  9.1.0.4867
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 导出 user 的数据库结构
CREATE DATABASE IF NOT EXISTS `user` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `user`;


-- 导出  表 user.details 结构
CREATE TABLE IF NOT EXISTS `details` (
  `id` int(30) NOT NULL AUTO_INCREMENT COMMENT '详情id',
  `m_id` int(30) DEFAULT NULL COMMENT '资源',
  `write_time` varchar(30) DEFAULT NULL COMMENT '填报时间',
  `found_time` varchar(30) DEFAULT NULL COMMENT '发现时间',
  `serial_number` varchar(30) DEFAULT NULL COMMENT '隐患编号',
  `write_name` varchar(30) DEFAULT NULL COMMENT '填报人',
  `phone` varchar(30) DEFAULT NULL COMMENT '联系电话',
  `describe` varchar(30) DEFAULT NULL COMMENT '隐患描述',
  `plan` varchar(30) DEFAULT NULL COMMENT '进度',
  `photo` varchar(100) DEFAULT NULL COMMENT '照片',
  `video` varchar(100) DEFAULT NULL COMMENT '视频',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='隐患详情';

-- 正在导出表  user.details 的数据：~3 rows (大约)
DELETE FROM `details`;
/*!40000 ALTER TABLE `details` DISABLE KEYS */;
INSERT INTO `details` (`id`, `m_id`, `write_time`, `found_time`, `serial_number`, `write_name`, `phone`, `describe`, `plan`, `photo`, `video`) VALUES
	(1, 1, '2019-9-21 14:40', '2019-9-21 14:40', '11111', '张三', '14785236912', '烟雾危机', '施工', '/upload/5454b919-fc5d-4c98-bffb-5f5b472f62d0.jpg', '/video/mda-ib0thgmpuqqb9iky.mp4'),
	(2, 2, '2019-9-21 14:30', '2019-9-21 14:30', '11112', '李四', '14785236912', '吊车施工', '完成', '/upload/109ea8cd-f2d2-4028-9489-10c693acc8ef.png', '/video/mda-jikp6thim4nanaes.mp4'),
	(3, 3, '2019-9-21 14-43', '2019-9-21 14-43', '11113', '王五', '14785236912', '烟雾危机', '未进行', '/upload/a01d1fa1-290d-469b-b5e4-c26bea471a4e.jpg', '/video/mda-ib0thgmpuqqb9iky.mp4');
/*!40000 ALTER TABLE `details` ENABLE KEYS */;


-- 导出  表 user.message 结构
CREATE TABLE IF NOT EXISTS `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '资源id',
  `unit` varchar(30) DEFAULT NULL COMMENT '单位',
  `create_time` varchar(50) DEFAULT NULL COMMENT '创建时间',
  `v_grade` varchar(30) DEFAULT NULL COMMENT '电压等级',
  `hazard_type` varchar(30) DEFAULT NULL COMMENT '隐患类型',
  `hazard_level` varchar(30) DEFAULT NULL COMMENT '隐患等级',
  `x` varchar(30) DEFAULT NULL COMMENT 'x坐标',
  `y` varchar(30) DEFAULT NULL COMMENT 'y坐标',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='资源信息表';

-- 正在导出表  user.message 的数据：~6 rows (大约)
DELETE FROM `message`;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` (`id`, `unit`, `create_time`, `v_grade`, `hazard_type`, `hazard_level`, `x`, `y`) VALUES
	(1, '山东济南电网', '2019-09-21 14:40:00', '220', '烟 火', '1', '117.174198', '36.681824'),
	(2, '山东淄博电网', '2019-09-21 14:42:00', '360', '吊车', '2', '118.079651', '36.604396'),
	(3, '山东滨州电网', '2019-09-21 14:43:00', '480', '烟', '1', '116.092743', '35.061345'),
	(4, '山东济南电网', '2019-09-20 14:00:00', '360', '吊车', '2', '118.502789', '36.292255'),
	(5, '山东淄博电网', '2019-09-18 14:30:00', '220', '火', '2', '117.840486', '37.459897'),
	(6, '山东济南电网', '2019-09-17 14:00:00', '360', '烟', '1', '116.037551', '37.12181');
/*!40000 ALTER TABLE `message` ENABLE KEYS */;


-- 导出  表 user.oauth_client_details 结构
CREATE TABLE IF NOT EXISTS `oauth_client_details` (
  `client_id` varchar(128) NOT NULL,
  `resource_ids` varchar(256) DEFAULT NULL,
  `client_secret` varchar(256) DEFAULT NULL,
  `scope` varchar(256) DEFAULT NULL,
  `authorized_grant_types` varchar(256) DEFAULT NULL,
  `web_server_redirect_uri` varchar(256) DEFAULT NULL,
  `authorities` varchar(256) DEFAULT NULL,
  `access_token_validity` int(11) DEFAULT NULL,
  `refresh_token_validity` int(11) DEFAULT NULL,
  `additional_information` varchar(4096) DEFAULT NULL,
  `autoapprove` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  user.oauth_client_details 的数据：~1 rows (大约)
DELETE FROM `oauth_client_details`;
/*!40000 ALTER TABLE `oauth_client_details` DISABLE KEYS */;
INSERT INTO `oauth_client_details` (`client_id`, `resource_ids`, `client_secret`, `scope`, `authorized_grant_types`, `web_server_redirect_uri`, `authorities`, `access_token_validity`, `refresh_token_validity`, `additional_information`, `autoapprove`) VALUES
	('client', NULL, '$2a$10$.rs5Meq4Lujb546sGTvNfOOH5oklOuw.mVhq6ZIwpJo1tIzgY7Rp2', 'app', 'authorization_code', 'http://www.funtl.com', NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `oauth_client_details` ENABLE KEYS */;


-- 导出  表 user.tree 结构
CREATE TABLE IF NOT EXISTS `tree` (
  `id` int(11) DEFAULT NULL COMMENT '数据id',
  `conent` varchar(10) DEFAULT NULL COMMENT '数据内容',
  `parentid` int(11) DEFAULT NULL COMMENT '二级权限'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  user.tree 的数据：~4 rows (大约)
DELETE FROM `tree`;
/*!40000 ALTER TABLE `tree` DISABLE KEYS */;
INSERT INTO `tree` (`id`, `conent`, `parentid`) VALUES
	(1, '权限管理', NULL),
	(2, '系统管理', NULL),
	(3, '用户管理', NULL),
	(4, '角色管理', 4);
/*!40000 ALTER TABLE `tree` ENABLE KEYS */;


-- 导出  表 user.userinfo 结构
CREATE TABLE IF NOT EXISTS `userinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `role` int(11) NOT NULL DEFAULT '0' COMMENT '0表示管理员1普通用户',
  `username` varchar(30) NOT NULL COMMENT '用户名',
  `password` varchar(30) NOT NULL COMMENT '用户密码',
  `phone` text NOT NULL COMMENT '用户照片',
  `create_time` varchar(50) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COMMENT='用户信息表';

-- 正在导出表  user.userinfo 的数据：~25 rows (大约)
DELETE FROM `userinfo`;
/*!40000 ALTER TABLE `userinfo` DISABLE KEYS */;
INSERT INTO `userinfo` (`id`, `role`, `username`, `password`, `phone`, `create_time`) VALUES
	(1, 0, 'root', '123456', '', '2019-09-09 16:10:14'),
	(2, 1, '张三', '12345465', '', '2019-09-09 16:29:38'),
	(3, 1, '李四', '52151', '', '2019-09-09 16:51:49'),
	(5, 1, '王五', 'hjcasnjc', '', '2019-09-09 16:58:17'),
	(6, 1, 'min', '123456', '', '2019-09-10 13:08:04'),
	(7, 1, '123', '123456', '', '2019-09-10 13:16:13'),
	(8, 1, '15661', '123456', '', '2019-09-10 13:25:22'),
	(9, 1, 'podnv', '147852', '', '2019-09-10 13:41:06'),
	(10, 1, '西游记', 'qazxsw', '', '2019-09-10 13:43:22'),
	(11, 1, '西游', 'qazxsw', '', '2019-09-10 13:45:08'),
	(12, 1, 'Java', '159951', '/upload/60e2997d-94b3-477a-af6d-47c6c4126e29.jpg', '2019-09-11 08:38:20'),
	(14, 1, 'php', '159951', '/upload/a5821b9e-617a-48d6-8827-14f421012d5a.jpg', '2019-09-11 08:51:35'),
	(15, 1, '刘玲', '123456', '/upload/a01d1fa1-290d-469b-b5e4-c26bea471a4e.jpg', '2019-09-11 13:12:33'),
	(16, 1, '钱', '123456', '/upload/81bcadb5-61cb-4c68-a2a1-5999e0c083d8.png', '2019-09-11 14:05:14'),
	(17, 1, 'vdfvdbfg', '123456', '/upload/109ea8cd-f2d2-4028-9489-10c693acc8ef.png', '2019-09-12 11:53:25'),
	(18, 1, 'ro', '123456', '/upload/1d7c29cc-95a9-46d0-a1ad-2b5540d81017.jpg', '2019-09-16 08:42:59'),
	(19, 1, 'cdkjn cv', '123456', '/upload/ab402507-77bc-4ea9-8169-52349ccbf8c2.png', '2019-09-16 10:52:29'),
	(20, 1, 'zhangsan', '147852', '/upload/b7bfdb07-8e29-4ace-bc2c-eaa287556840.jpg', '2019-09-16 15:30:21'),
	(21, 1, 'root1', '123456', '/upload/5454b919-fc5d-4c98-bffb-5f5b472f62d0.jpg', '2019-09-19 10:30:02'),
	(22, 1, 'root123', '1234', '15425445', NULL),
	(23, 1, 'root1234', '12345465', '44545465', '2019-09-26 11:44:50'),
	(24, 1, 'a', '123456', '155758', '2019-09-26 11:51:18'),
	(25, 1, 'b', '147852', '155758', '2019-09-26 11:54:49'),
	(26, 1, 'c', '147852', '/upload/53823b65-bbff-433f-bc06-a72059f69a93.png', '2019-09-26 11:57:27'),
	(27, 1, 'zhangsan1', '123456', '/upload/69d3bfb7-0a4a-47ce-b1b8-a22358e3a81d.jpg', '2019-10-07 14:17:21');
/*!40000 ALTER TABLE `userinfo` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
